import React from 'react'
import './Header.css'

const Header = () => {
    return (
        <div className='header'>
            <div className='header-contents'>
                <h2>Your Favourite Tasty Meals, Just a Click Away!</h2>
                <p>Welcome to [Your Website Name], your go-to destination for fast, fresh, and delicious food delivered right to your doorstep. Whether you're craving local street food, gourmet meals, or late-night snacks, we’ve got it all—served hot and hassle-free.</p>
                <button>View Menu</button>
            </div>
        </div>
    )
}

export default Header
